<?php

namespace App\Http\Controllers;

use App\Models\UserService;
use Illuminate\Http\Request;
use App\Models\ServiceManReservation;

class UserServiceController extends Controller
{
    public function store(Request $request)
    {
        // Validate the form data
        $validatedData = $request->validate([
            'city' => 'required|string',
            'street_name' => 'required|string',
            'building_number' => 'required|integer',
            'floor_number' => 'nullable|integer',
            'house_number' => 'required|integer',
            'full_address' => 'required|string',
            'phone_number' => 'required|string',
            'user_id' => 'required|integer',
            'reservation_id' => 'required|integer',
            'first_time'=> 'required|date',
            'payment_method' => 'required|string',
            // Add more validation rules as needed
        ]);
        // Create a transaction id and pass it into userService 
        $validatedData['transaction_id'] = uniqid();
        // Store the data in the database
        UserService::create($validatedData);
        
        $reservationPeriod=ServiceManReservation::where('id',$validatedData['reservation_id'])->first();
        $reservationPeriodTime=$reservationPeriod->period->period;
        // Redirect back or to any other page after successful submission
        // i want pass transaction id to the next page as values 
        return redirect(route("bank-information"))->with('message','Your details have been added!')->with('transaction_id', $validatedData['transaction_id'])->with('reservationPeriodTime', $reservationPeriodTime);
        // return redirect(route("bank-information"))->with('message','Your details have been added!');
    }
}
