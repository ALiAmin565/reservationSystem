<div class="sidebar">
    <nav class="nav justify-content-center">
        <a id="facebook" class="nav-link d-none d-sm-flex" href="#" target="_blank">
            <i class="fab fa-facebook-f"></i>
        </a>
        <a id="twitter" class="nav-link d-none d-sm-flex" href="#" target="_blank" title="Tweet"
            rel="noopener noreferrer nofollow">
            <i class="fab fa-twitter"></i>
        </a>
        <a id="instagram" class="nav-link d-none d-sm-flex" href="#" target="_blank" rel="noopener">
            <i class="fab fa-instagram"></i>
        </a>

        <a id="telegram" class="nav-link d-none d-sm-flex" href="#" target="_blank"
            rel="noopener noreferrer nofollow">
            <i class="fab fa-telegram-plane"></i>
        </a>
        <a id="whatsapp" class="nav-link d-none d-sm-flex " href="#" target="_blank"
            rel="noopener noreferrer nofollow">
            <i class="fab fa-whatsapp"></i>
        </a>
        <a id="share" data-toggle="modal" data-target="#social" class="nav-link d-flex d-sm-none" href="#">
            <i class="fas fa-share-alt"></i>
        </a>
    </nav>
</div>
