<!doctype html>
<html lang="ar" dir="rtl">


<!-- Mirrored from www.almutahidah.com/HourlyContract/about by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 28 Mar 2024 08:37:13 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description"
        content="  ">
    <meta name=" ">
    <meta name="author" content="">
    <meta name="google-site-verification" content="JnGSi3Ss6KrIbeMaNeH7bjKzE2zpsFd1UHcSk28uNWI" />
    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                '../../www.googletagmanager.com/gtm5445.html?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-T5DZNKT');
    </script>
    <!-- End Google Tag Manager -->
       <link rel="icon" href="https://shining.ajeerco.com/wp-content/uploads/2023/10/cropped-logo6.png">

        <title>نظافة ولمعة</title>

    <!-- Bootstrap core CSS -->
    <link href="Content/css/bootstrap.min.css" rel="stylesheet">
    <link href="Content/css/main10.css?v=1" rel="stylesheet">
    <link href="Content/fakeloader.css" rel="stylesheet" />
    <link href="Content/sweetalert2.css" rel="stylesheet" />



    <link href="Content/fontawesome/css/all.min.css" rel="stylesheet" />
    <link href="Content/jquery-ui.min.css" rel="stylesheet" />
    <link href="Content/css/fileinput.css" media="all" rel="stylesheet" type="text/css" />
    <link href="Content/css/select2.min.css" rel="stylesheet" />
    <!--rate yo scripts-->
    <link rel="stylesheet" href="../../cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">

    <script src="bundles/jqueryc819?v=77eIT0HS5BH1Zu24jr-MDmHhMNzECnPygeVd9lfPQfk1"></script>


    <style>
        .field-validation-valid {
            display: none;
        }
    </style>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-876342861"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'AW-876342861');
    </script>
    @livewireStyles
</head>

<body>
    <x-layout.preloader />
    <x-layout.header />
    <x-layout.sidebar />
    {{ $slot }}

    <x-layout.footer />
    <x-layout.policy />
    <x-layout.scripts />
    <style>
        .tooltip-in-menu .tooltip-inner {
            background-color: #bd1c03;
            border-radius: 1rem;
            padding: 1rem;
            font-family: 'CoconNextArabic' !important
        }

        .tooltip-in-menu {
            margin-right: 2rem;
        }

        .tooltip-in-menu .arrow {
            display: none !important
        }
    </style>
    @livewireScripts
</body>

<!-- Mirrored from www.almutahidah.com/HourlyContract/about by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 28 Mar 2024 08:37:16 GMT -->

</html>
