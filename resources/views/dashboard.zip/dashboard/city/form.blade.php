<div class="row mb-3">
    <label class="col-sm-2 col-form-label"> المدينة </label>
    <div class="col-sm-10">
        <input type="text" name="name" class="form-control" placeholder="قم بأدخال المدينة"
            value="{{ $city->name }}">
    </div>
</div>
